package com.bangkit.woai.data

data class WorkoutTraining(
    val title: String,
    val imageResId: Int
)
