package com.bangkit.woai.data.preferences

class Constant {
    companion object {
        val PREF_IS_LOGIN = "PREF_IS_LOGIN"
        val PREF_EMAIL = "PREF_EMAIL"
        val PREF_TOKEN = "PREF_TOKEN"
        val PREF_NAME = "PREF_NAME"
        val PREF_ID = "PREF_ID"
        val PREF_WEIGHT = "PREF_WEIGHT"
        val PREF_HEIGHT = "PREF_HEIGHT"
        val PREF_BMI = "PREF_BMI"
        val PREF_IMG = "PREF_IMG"

    }
}