package com.bangkit.woai.views.profile

import android.view.View
import androidx.lifecycle.ViewModel
import com.bangkit.woai.data.repository.UserRepository

class ProfileViewModel(private val userRepository: UserRepository) : ViewModel() {

}