package com.bangkit.woai.di

object Injection {
}