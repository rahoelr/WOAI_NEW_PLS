package com.bangkit.woai.views.details_training

class DetailViewModel {
}