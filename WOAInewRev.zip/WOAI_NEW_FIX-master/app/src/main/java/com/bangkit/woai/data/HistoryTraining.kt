package com.bangkit.woai.data

data class HistoryTraining (
    val date: String,
    val time: String
)