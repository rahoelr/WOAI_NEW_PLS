package com.bangkit.woai.data.response

import com.google.gson.annotations.SerializedName

data class DeleteActivityResponse(

	@field:SerializedName("message")
	val message: String? = null
)
